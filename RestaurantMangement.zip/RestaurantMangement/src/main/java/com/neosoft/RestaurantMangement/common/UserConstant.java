package com.neosoft.RestaurantMangement.common;

public class UserConstant {

    public static final String DEFAULT_ROLE = "ROLE_EMPLOYEE";
    public static final String[] ADMIN_ACCESS = {"ROLE_ADMIN","ROLE_MANAGER"};
    public static final String[] MANAGER_ACCESS = {"ROLE_MANAGER"};
}
