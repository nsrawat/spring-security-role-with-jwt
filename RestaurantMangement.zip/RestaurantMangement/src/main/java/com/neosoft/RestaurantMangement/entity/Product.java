package com.neosoft.RestaurantMangement.entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="product_details")
public class Product {

    @Id
    @GeneratedValue
    private int productId;

    private String productName;

    private long productPrice;
}
