package com.neosoft.RestaurantMangement.controller;

import com.neosoft.RestaurantMangement.entity.Product;
import com.neosoft.RestaurantMangement.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductRepository repository;

    @PostMapping("/add")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public Product addProduct(@RequestBody Product product) {
        return repository.save(product);
    }

    @GetMapping("/all")
    public List<Product> getAllProducts(){
        return repository.findAll();
    }

    @GetMapping("/{productName}")
    public Product findProductByName(@PathVariable String productName) {
        return repository.findByProductName(productName).orElse(null);
    }

    @DeleteMapping("/{productId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String deleteProduct(@PathVariable int productId) {
        repository.deleteById(productId);
        return "product deleted !!"+productId;
    }

    @PutMapping("/{productId}")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String updateProduct( @RequestBody Product product, @PathVariable Integer productId)
    {
        Optional<Product> products = repository.findById(productId);

        if(products.isPresent()) {
            Product newProduct = products.get();
            newProduct.setProductName(product.getProductName());
            newProduct.setProductPrice(product.getProductPrice());
            newProduct = repository.save(newProduct);

            return "product upadated: "+ productId;
        }
        else {
            return "product NOT FOUND: "+ productId;
        }

    }
}
