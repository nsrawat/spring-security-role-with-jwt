package com.neosoft.RestaurantMangement.config;

import com.neosoft.RestaurantMangement.filter.JwtRequestFilter;
import com.neosoft.RestaurantMangement.service.GroupUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private GroupUserDetailsService groupUserDetailsService;
    @Autowired
   private JwtRequestFilter jwtRequestFilter;
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
         auth.userDetailsService(groupUserDetailsService);
    }
    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.csrf().disable().authorizeRequests()
                //.antMatchers("/product/").permitAll()
                .antMatchers("/user/**").hasAuthority("ROLE_ADMIN")
                .and().httpBasic();

        http.authorizeRequests().antMatchers("/token").permitAll().anyRequest()
                .authenticated().and().exceptionHandling().and()
                // We don't need sessions to be created.
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);

    }
}
//        // Disable CSRF
//        http.csrf().disable()
//                // Only admin can perform HTTP delete operation
//                .authorizeRequests().antMatchers(HttpMethod.DELETE).hasRole(Role.ADMIN)
//                // any authenticated user can perform all other operations
//                .antMatchers("/products/**").hasAnyRole(Role.ADMIN, Role.USER).and().httpBasic()
//                // Permit all other request without authentication
//                .and().authorizeRequests().anyRequest().permitAll()
//                // We don't need sessions to be created.
//                .and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//
//